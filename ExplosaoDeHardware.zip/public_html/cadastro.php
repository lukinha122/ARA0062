<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
    href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@300&display=swap" rel="stylesheet"
  />
  
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Cadastro</title>
  </head>
  <body>
      <style>
          
          body{
            background-image:url("https://www.maistecnologia.com/wp-content/uploads/2018/03/nuclear-1024x518.png");
            background-attachment:fixed;
            background-size:100%;
            background-repeat:no-repeat;
           
            
            
        }
          
          
          
      </style>
      <center><h2><font color="white">Explosão de Hardware</font></h2></center>
      <br>
    <center><h3><font color="white">Cadastro de Login</font></h3></center>
    
    <div class="container">
        
        <div id="cliente_login" class="login">
    <span id="clienteLogin_erros" class="validation-errors" style="display:none">
    </span>
    <form action="inserir.php?t=usuario" method="post" id="meuForm">
        <fieldset class="fLogin">
            <p class="email mb-nova">
                <em><font color="white">Digite seu e-mail</font></em>
                <br>
                 <label for="Email"><font color="white">E-mail:</font></label>
                <input class="iEmail" data-val="true" data-val-length="E-mail não pode exceder 50 caracteres" data-val-length-max="50" data-val-regex="Formato de E-mail inválido" data-val-regex-pattern="\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" data-val-required="O campo E-mail é obrigatório" id="Email" name="Email" placeholder="Digite o seu e-mail" tabindex="1" type="text" value="" />
                <span class="field-validation-valid" data-valmsg-for="Email" data-valmsg-replace="true"></span>
            </p>
                        <p class="password">
                <a href="#" title="Esqueci meu e-mail" class="lnkPop" id="lnkEsqueciMeuEmail" tabindex="5"><font color="white">Esqueci meu e-mail</font></a>
               <br><br>
            
                <label for="Senha"><font color="white">Senha:</font></label>
                <input class="iPassword" data-val="true" data-val-length="O campo Senha deve ter entre 4 e 18 caracteres" data-val-length-max="18" data-val-length-min="4" data-val-required="O campo Senha é obrigatório" id="Senha" name="Senha" placeholder="Digite a sua senha" tabindex="2" type="password" />
                <span class="field-validation-valid" data-valmsg-for="Senha" data-valmsg-replace="true"></span>
            </p>
            <p class="pPossuiCadastro">
                <a href="#" title="Esqueci minha senha" class="lnkPop" id="lnkEsqueciSenha" tabindex="7"><font color="white">Esqueci minha senha</font></a>
                <br><br>
                <em><font color="white">Já possui um cadastro?</font></em><br>
                <input type="radio" id="rbCadastrado" name="cadastro" checked="checked" tabindex="3" class="rbLoginCadastro" />
                <label for="rbCadastrado">Sim</label><br>
                <input type="radio" id="rbNaoCadastrado" name="cadastro" class="rbLoginCadastro" />
                <label for="rbNaoCadastrado"><font color="white">Não, essa é a minha primeira compra</font></label>

            <div id='recaptcha' class="g-recaptcha"
                 data-sitekey="6LdDW6kZAAAAAJlxiPCubESVi3uvM9MaM2mI5tIX"
                 data-callback="callbackCaptcha"
                 data-size="invisible"></div>
            <input type="submit" id="btnClienteLogin" class="bt btLogin" value="continuar" tabindex="4" />
            <a href="/Checkout?Pagina=cadastrar&ReturnUrl=https:/https://explosaodehardware.000webhostapp.com/menu.php/" id="btnClienteCadastrar" tabindex="4" class="bt btLogin"></a>
        </fieldset>
        
<link href="/Content/EXPLOSAO DE HARDWARE/css/layoutJornadaUX.css" rel="stylesheet"  />
        
    </div>
    
    
    
    
    

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>