<?php
session_start();

if ( ! isset($_SESSION["verdadeiro"]) ){
    echo "
    <script>
    window.location.replace('menu.php');
    </script>
    ";
    
}

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>EXPLOSAO DE HARDWARE</title>
  
  </head>
  <body>
<style>
body{
            background-image:url("https://www.maistecnologia.com/wp-content/uploads/2018/03/nuclear-1024x518.png");
            background-attachment:fixed;
            background-size:100%;
            background-repeat:no-repeat;
           
            
            
        }

    
    
</style>
      <center><h1>EXPLOSAO DE HARDWARE</h1></center>
    <hr>
    
    <ul class="nav justify-content-end">
        <li class="nav-item">
        <a class="nav-link" href="login.php"><font color="white">Sair</font></a>
  </li>
      <li class="nav-item">
        <a class="nav-link" href="contato.php"><font color="white">Formulario de contato</font></a>
  </li>
  <li class="nav-item">
        <a class="nav-link" href="cadastroblog.php"><font color="white">Cadastro de Blog</font></a>
        </li>
</ul>

<hr>
  <center><h1></h1></center>
  <br>
  <div class="container"><!-- INCIO DE CONTAINER!-->
      
      <div class="card-deck">
  <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/cd2e75e2636e632c04e681018268259c/r/o/rog-strix-z490-f-gaming.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">PLACA MAE ASUS ROG STRIX Z490-F GAMING DDR4 SOCKET LGA1200 INTEL Z490</h5>
      <p class="card-text">Soquete Intel® LGA 1200: pronta para processadores Intel® Core™ de 10ª geração.
Solução de energia ideal: 12 + 2 estágios de energia com conector de energia ProCool II, alloy chokes de alta qualidade e capacitores duráveis para suportar processadores com vários núcleos.
Projeto térmico otimizado: dissipador de calor MOS em forma de U, extenso dissipador de calor VRM, dissipadores de calor M.2 integrados duplos, incluindo um suporte para montar uma ventoinha adicional para mais refrigeração.
Rede de alto desempenho: M.2 socket com E-key e Rede Intel® 2.5 Gb com ASUS LANGuard.
Melhor conectividade gaming: Suporta HDMI 1.4 e DisplayPort 1.4, M.2 duplo e conectores USB 3.2 Gen 2 Tipo A e Tipo C®.
Controle Inteligente: ferramentas exclusivas da ASUS, incluindo AI Overclocking, AI Cooling e AI Networking, ajudando você a configurar seus jogos com facilidade.
Design DIY amigável: Escudo I/O pré-montado, BIOS Flashback, Q-Code e FlexKey.
Personalização incomparável: iluminação Aura Sync RGB exclusiva da ASUS, incluindo headers RGB e headers endereçáveis Gen 2
Áudio gaming líder do setor: áudio de alta fidelidade com SupremeFX S1220A, DTS® Sound Unbound e Sonic Studio III para atrair você para a ação..</p>
    </div>
  </div>
 
  <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/cd2e75e2636e632c04e681018268259c/c/g/cgr-bs-5005.jpg" class="card-img-top" alt="...">
    <div class="card-body">
        <hr>
      <h5 class="card-title">FONTE COUGAR VTE 500 80PLUS BRONZE PFC ATIVO, CGR BS-500</h5>
      <p class="card-text">Características:

- Marca: Cougar

- Modelo: 31VE050.0005P

 

Especificações:

- Potência: 500W

 

Entrada AC:

- 100-240V 

- 50-60Hz 10-6A

 

Saída DC:

- +3.3V: 16A 135W 

- +5V: 18A 135W

- +12V: 37.5A 450W

- -12V: 0.3A

- +5Vsb: 2.5A

 

Conectores:

- Principal 24(20+4) Pins: 1x

- CPU 8(4+4) Pins 8 Pins: 1x

- Periféricos 4 Pins: 2x

- SATA 5 Pins: 5x

- PCI-E 8(6+2) Pins: 2x



Informações adicionais:

- Eficiência Extremamente Elevada

- Correção ativa do fator de potência (PFC ativo)

- Saída de tensão ultra-estável

- Compatível com a mais recente tecnologia de PC

- Design integrado da entrada de ar

- Suporte a tecnologia Multi-GPU

- Proteções completas com OCP, SCP, OVP, UVP, OPP

 

Conteúdo da embalagem:

- Fonte Cougar


Peso
1840 gramas (bruto com embalagem).</p>
    </div>
  </div>
  
  <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/cd2e75e2636e632c04e681018268259c/b/x/bx80684i79700k454.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">PROCESSADOR INTEL CORE I7-9700K OCTA-CORE 3.6GHZ (4.9GHZ TURBO) 12MB CACHE</h5>
      <p class="card-text">Marca
Intel

Modelo
i7-9700K

Número de núcleos
8

Threads
8

Frequência
3,60 GHz

Frequência turbo max
4,90 GHz

Cache
SmartCache de 12 MB

Velocidade do barramento
8 GT / s DMI3

TDP
95,0 W

Gráficos
Gráficos de processador
Intel® UHD 630

Frequência básica de gráficos
350 MHz

Frequência dinâmica máxima dos gráficos
1.20 gigahertz

Vídeo Graphics Max Memory
64 GB

Suporte 4K
Sim, a 60Hz

Suporte DirectX
12

Suporte OpenGL
4.5

Cooler Box
Não incluso

Tecnologias avançadas
Memória Intel® Optane ™ Suportada
Tecnologia Intel® Turbo Boost: 2.0
Elegibilidade da Plataforma Intel® vPro
Tecnologia de virtualização Intel® (VT-x)
Tecnologia de virtualização Intel® para E / S direcionada (VT-d)
Intel® TSX-NI
Intel® 64
Conjunto de instruções de 64 bits
Extensões do conjunto de instruções: Intel® SSE4.1, Intel® SSE4.2, Intel® AVX2
Estados Ociosos
Tecnologia Enhanced Intel SpeedStep®
Tecnologias de Monitoramento Térmico
Tecnologia Intel® Identity Protection
Programa de Plataforma de Imagem Estável Intel® (SIPP).</p>
    </div>
  </div>
  
   <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/cd2e75e2636e632c04e681018268259c/c/l/cl-w138-pl14sw-a96262.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">WATER COOLER THERMALTAKE WATER 3.0 RIING 280 RGB, CL-W138-PL14SW-A</h5>
      <p class="card-text">Marca
Thermaltake

Modelo
CL-W138-PL14SW-A

Compatibilidade
Intel LGA 2011-3 / 2011/1366/1156/1155/1151/1150
AMD AM4 / FM2 / FM1 / AM3 + / AM3 / AM2 + / AM2

Water Block
Material: Cobre

Bomba
Tensão nominal: 12 V
Corrente nominal: 175 mA

Dimensão da ventoinha
140 x 140 x 25 mm

Rapidez
800 ~ 1500 R.P.M (PWM)
400 ~ 1000 R.P.M (Modo de Ruído Baixo)

Nível de ruído
18,5 ~ 26,4 dB-A

Tensão nominal
12 V

Máx. Fluxo de ar
22,14 ~ 40,6 CFM

Máx. Pressão
0,57 ~ 2,01 mm-H2O

Conector
5 pinos

Radiador
Dimensão: 313 x 139 x 27 mm

Tubo
Comprimento: 326 mm

Material
Tubo trançado.</p>
    </div>
</div>
  
</div>
     <BR>
     <div class="card-deck"> <!--SEGUNDA!-->
  <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/6ee86225acc73f593166d49264424d36/c/m/cmr16gx4m2c3000c15_4.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">MEMORIA CORSAIR VENGEANCE RGB 16GB (2X8) DDR4 3000MHZ PRETA, CMR16GX4M2C3000C15</h5>
      <p class="card-text">Marca
Corsair

Modelo
CMR16GX4M2C3000C15

Dissipador de Calor
Alumínio anodizado

Configuração da memória
Dois / Quadro Canais

Série de memória
Vengeance RGB

Tipo de memória
DDR4

Formato da memória do pacote
DIMM

Perfil de desempenho
XMP 2.0

Iluminação LED
RGB

Tamanho da memória
16GB (2 x 8GB)

Latência
15-17-17-35

Velocidade
3000MHz

Voltagem
1.35V.</p>
    </div>
  </div>
 
  <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/cd2e75e2636e632c04e681018268259c/9/1/912-v381-2274.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">PLACA DE VIDEO MSI RADEON RX 5600 XT 6GB MECH OC 128-BIT, 912-V381-227</h5>
      <p class="card-text">Marca
MSI

Modelo
912-V381-227

GPU
Radeon ™ RX 5600 XT

Núcleos
2304 Unidades

Clock
Boost: Até 1620 MHz
Game: Até 1460 MHz
Base: 1235 MHz

Clock de memória
14 Gbps

Tamanho de Memória
6GB GDDR6

Interface de memória
192-Bits

Barramento padrão
PCI Express 4.0

OpenGL
4.6

Interface
3 x DisplayPort(v1.4)
1 x HDMI 2.0bx
Suporte HDCP: Sim

Máximo de exibições
4

DirectX
12

Resolução máxima
7680 x 4320

Conector
1 x 8 pinos

Dimensões
231 x 127 x 46 mm.</p>
    </div>
  </div>
  
  <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/cd2e75e2636e632c04e681018268259c/s/t/st10000vn0008.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">HD SEAGATE IRONWOLF 10TB 3.5" SATA III 6GB/S, ST10000VN0008</h5>
      <p class="card-text">Marca
Seagate

Modelo
ST10000VN0008

Interface
SATA 6Gb/s

Capacidade
10TB

Tipo
HDD 3.5"

Cache
256 MB

RPM
7.200</p>.</p>
    </div>
  </div>
  
  <div class="card">
    <img src="https://media.pichau.com.br/media/catalog/product/cache/cd2e75e2636e632c04e681018268259c/g/p/gp-asacne2100tttdr5.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">SSD GIGABYTE AORUS RGB AIC 1TB NVME, GP-ASACNE2100TTTDR
</h5>
      <p class="card-text">Marca
Gigabyte

Modelo
GP-ASACNE2100TTTDR

Interface
PCI-Express 3.0 x4, NVMe 1.3

Formato
PCI Express Card

Capacidade
1TB

NAND
3D TLC ToshiBa BiCS3

Cache DDR externo
1024MB

Velocidade de Leitura
Até 3480 MB/s

Velocidade de Gravação
Até 3080 MB/s

Temperatura de Operação
0 ° C a 70 ° C

Temperatura de Armazenamento
-40 ° C a 85 ° C.</p>
</div>
  </div> 
  </div> <!--fim das div!-->
  <hr>
             
 
 
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>