<?php
session_start();

$login = $_POST ["login"];
$senha = $_POST ["senha"];

if ($login == "admin" && $senha == "1234") {
    
    $_SESSION["verdadeiro"]=true;
    
$html = "

            
        <script>
            
            window.location.replace('https://explosaodehardware.000webhostapp.com/menu.php');
            
        </script>

";
    
}else {
    session_destroy();
    $html = "
<!doctype>
<html>
<head> <title> Pagina de Verificaçao </title> </head>
<body>
<h1> Seu login ou sua senha estão SAO INVALIDOS </h1>
  </body

</html>

";

}
    

echo $html;
?>